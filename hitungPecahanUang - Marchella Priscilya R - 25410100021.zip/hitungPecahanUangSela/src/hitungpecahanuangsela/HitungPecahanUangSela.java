/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hitungpecahanuangsela;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author ASUS
 */
public class HitungPecahanUangSela {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)throws IOEcception, IOException {
        // deklarasi variabel
    int uang;
    int duaPuluhRibu;
    int sepuluhRibu;
    int seribuan;
    int limaRatusan;
    int duaRatusan;
    int seratusan;
    BufferedReader br= new BufferedReader (new InputStreamReader(System.in));
    
    
   //Inputan
        System.out.println("Masukkan jumlah uang");
        uang = Integer.parseInt(br.readLine());
        
        //Proses perhitungan pecahan
        duaPuluhRibu = uang / 20000;
        uang = uang % 20000;
        
        sepuluhRibu = uang / 10000;
        uang = uang % 10000;
        
        seribuan = uang / 1000;
        uang = uang % 1000;
        
        limaRatusan = uang / 500;
        uang = uang % 500;
        
        duaRatusan = uang / 200;
        uang = uang % 200;
        
        seratusan = uang / 100
        uang = uang % 100;
        
        //output hasil
        System.out.println("20000 :" + duaPuluhRibu);
        System.out.println("10000 :" + sepuluhRibu);
        System.out.println("1000 :" + seribuan);
        System.out.println("500 :" + limaRatusan);
        System.out.println("200 :" + duaRatusan);
        System.out.println("100 :" + seratusan);

        
   
    }
    
}
