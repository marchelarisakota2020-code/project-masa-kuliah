import java.util.Scanner; 
public class prak3 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

       
        System.out.print("Masukkan Bilangan Ganjil = ");
        int n = input.nextInt();

       
        for (int i = 1; i <= n; i++) {
            System.out.print(i);
        }
        System.out.println();

        // Bagian tengah (1 sampai n ke bawah)
        for (int i = 1; i <= n; i++) {
            System.out.println(i);
        }

        // Baris terakhir (123...)
        for (int i = 1; i <= n; i++) {
 
            System.out.print(i);
  
        }
}   }

    


    
    
        

